# -*- coding: utf-8 -*-
"""
Created on Tue Mar 14 17:26:14 2023

@author: DELL
"""

import jieba

def word_process(sentence):
    words=list(jieba.cut(sentence))#对文档进行jieba分词
    stopwords=[]
    with open('C:/Users/DELL/Desktop/python数据分析/python2/stopwords.txt','r',encoding='utf-8') as f0:
        for line in f0:
            stopwords.append(line.strip())#引入停用词表
    Words=[word for word in words if word not in stopwords]#去除停用词和标点
    doc=' '.join(Words)#生成不含停用词和标点，每个词以空格相连的字符串
    return doc
