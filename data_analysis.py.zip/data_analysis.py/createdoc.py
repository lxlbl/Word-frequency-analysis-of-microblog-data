# -*- coding: utf-8 -*-
"""
Created on Tue Mar 14 16:32:27 2023

@author: DELL
"""


import datetime

def day_doc(fpath):
    doc_by_day=dict()#字典，天数为键，那一天的所有微博组成的列表为值
    with open(fpath,'r',encoding='utf-8') as f:
        for line in f:
            l=line.strip().split('\t')#将文件的每一行进行处理
            fl_loc=l[0]
            fl_text=l[1]
            fl_time=l[2]
            time=datetime.datetime.strptime(fl_time,'%a %b %d %H:%M:%S %z %Y')#将每一行微博的时间格式化
            if time.day not in doc_by_day:
                doc_by_day[time.day]=[]
                doc_by_day[time.day].append(fl_text)
                #如果字典中没有这行微博的天数，就创建列表作为天数对应的值，并把该行微博加入列表中
            else:
                doc_by_day[time.day].append(fl_text)
                #如果字典中有这行微博对应的天数，就把这行微博加入到对应列表中
    return doc_by_day
            


     
    

