# -*- coding: utf-8 -*-
"""
Created on Tue Mar 14 17:44:08 2023

@author: DELL
"""

import createdoc
import process
from sklearn.feature_extraction.text import CountVectorizer
#from sklearn.feature_extraction.text import TfidfVectorizer
import ldamake
import matplotlib.pyplot as plt
from sklearn.decomposition import LatentDirichletAllocation


if __name__=='__main__':
    #将微博文件导入，产生以天数为键，该天数时的微博为值的字典
    doc_by_day=createdoc.day_doc('C:/Users/DELL/Desktop/python数据分析/python2/weibo.txt')
    documents=[]#列表中的元素表示某天的微博组成的字符串
    docs=[]#列表中的元素表示某天的微博分词后形成的字符串
    for key in doc_by_day.keys():
        documents.append(','.join(doc_by_day[key]))#将相同天数下的不同行微博合成一个字符串，用逗号隔开
    for sentence in documents:
        docs.append(process.word_process(sentence))#将同一天内的微博分词并去除停用词和标点，用空格相连成字符串
    # 将文本转换成词频矩阵
    vectorizer = CountVectorizer()
    # 将文本转换成tf-idf矩阵
    #vectorizer = TfidfVectorizer()
     
    X = vectorizer.fit_transform(docs)
    #print(X)
    
    
    
    ldamake.lda_make(3,X,vectorizer,documents)
    
    # 计算困惑度绘制elbow图确定主题数量
    perplexity_scores = []
    k_range = range(1, 6) # 假设k的范围是1到5
    for k in k_range:
        lda = LatentDirichletAllocation(n_components=k)
        lda.fit(X)
        perplexity_scores.append(lda.perplexity(X))
    plt.plot(k_range, perplexity_scores, '-o')
    plt.xlabel('Number of topics')
    plt.ylabel('Perplexity')
    plt.show() 
    
        
    