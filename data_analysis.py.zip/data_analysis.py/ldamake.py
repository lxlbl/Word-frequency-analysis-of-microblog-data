# -*- coding: utf-8 -*-
"""
Created on Tue Mar 14 18:38:01 2023

@author: DELL
"""

from sklearn.decomposition import LatentDirichletAllocation
import pickle

def lda_make(k,X,vectorizer,documents):
    # 使用LatentDirichletAllocation构建主题模型
    lda = LatentDirichletAllocation(n_components=k)
    lda.fit(X)
    # 输出每个主题对应的词语
    feature_names = vectorizer.get_feature_names()
    for i, topic in enumerate(lda.components_):
        print(f"Topic {i+1}:")
        top_words = [feature_names[j] for j in topic.argsort()[:-6:-1]]
        print(top_words)

    # 输出每篇文档的主题概率分布
    for i in range(len(documents)):
        print(f"Document {i+1}:")
        print(lda.transform(X[i]))
    # 输出结果

    pickle.dump((lda, X, vectorizer), open('./lda_model.pkl','wb'))